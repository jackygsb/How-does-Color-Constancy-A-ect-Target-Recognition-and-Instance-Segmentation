from setuptools import setup

setup(
    name='BboxTools',
    version='1.0.2',
    packages=[''],
    url='',
    license='BSD',
    author='Angtian Wang',
    author_email='angtianwang@gmail.com',
    description='A python toolbox for bounding box operation'
)
